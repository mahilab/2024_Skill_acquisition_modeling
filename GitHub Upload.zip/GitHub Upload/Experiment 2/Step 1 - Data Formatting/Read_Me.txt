Part 1 - Data Formatting
________________________

By Charles Weeks (crw12@rice.edu)

This folder contains all the files I used to create my .mat table that is analyzed by all the later codes. This MATLAB code is extremely specific to MT6 and will need to be heavily modified for future experiments.

In the end, you want a .mat table file with just four columns (exact names do not matter): subject number, trial number, performance metric, and average feedback given on that trial. You can add additional columns for additional performance metrics you plan on analyzing or for group assignments. Each subject will have as many rows as they have trials. Go ahead and remove subjects that you already know you do not want to analyze (e.g., path length non-compliance, data collection problems, etc.).

I reformatted my data using Data_Formatting.m. It requires MT6_trialtime.csv, MT6_sparc.csv, and MT6_subjectfeedback.csv.

MT6_trialtime and MT6_sparc are both formatted horizontally (with a column for each of the 40 trials) instead of vertically. Some subjects are already removed from these files due to path length non-compliance, data collection problems, or having too few or too many trials.

MT6_subjectfeedback.csv contains all subjects (none removed), including some with too few or too many trials. It is formatted vertically, but it uses blocks 1-4 and trials 1-10 instead of just trials 1-40. It contains a row for each instance a subject was given feedback during a trial (which was every 5 seconds, marked by the "Time" column.)

All of these CSV files contain 40 trials, but I only want to analyze the first 30 trials in this experiment (while the subjects were still receiving feedback).

Data_Formatting.m rectifies all of these problems and differences in formatting. It creates MT6_Data.mat as its output.