% Data_Formatting.m
% By Charles Weeks (crw12@rice.edu)

%% Part 1 - Import and transform MT6_trialtime.csv

% Load the trial time data including the header
data_with_header = readtable('MT6_trialtime.csv');

% Separate the header and the actual trial time data
headers = data_with_header.Properties.VariableNames;
data = data_with_header(2:end, :);

% Extract the number of subjects from the data
numSubjects = height(data);

% Initialize the arrays for the new format
Subject_Number = [];
Feedback_Group = [];
Trial_Number = [];
Trial_Time = [];

for i = 1:numSubjects
    % Repeat the ID and Feedback for each trial (40 times for each subject)
    Subject_Number = [Subject_Number; repmat(data{i,1}, 40, 1)];
    Feedback_Group = [Feedback_Group; repmat(data{i,2}, 40, 1)];
    
    % Create a column for trial numbers (1 to 40)
    Trial_Number = [Trial_Number; (1:40)'];
    
    % Extract the trial times for the subject (ensuring we only get 40 values)
    currentTrialTimes = table2array(data(i,3:42));
    Trial_Time = [Trial_Time; currentTrialTimes'];
end

% Combine the arrays into a new table
Metric_Data = table(Subject_Number, Feedback_Group, Trial_Number, Trial_Time);

%% Part 2 - Add MT6_sparc.csv to our data

% Load the SPARC data including the header
sparcData_with_header = readtable('MT6_sparc.csv');

% Separate the header and the actual SPARC data
sparcData = sparcData_with_header(2:end, :);

% Initialize the array for SPARC values
SPARC = [];

for i = 1:numSubjects
    % Extract the SPARC values for the subject (ensuring we only get 40 values)
    currentSPARC = table2array(sparcData(i,3:42));
    SPARC = [SPARC; currentSPARC'];
end

% Add the SPARC values to the averageFeedback table
Metric_Data.SPARC = SPARC;

%% Part 3 - Add average feedback using MT6_subjectfeedback.csv

% Step 1 - reduce the feedback csv to just trial averages
% Read in the feedback data
data = readtable('MT6_subjectfeedback.csv');

% Recalculate the trial number to be from 1 to 40
data.New_Trial = (data.Block - 1) * 10 + data.Trial;

% Define the grouping variables (so that it averages anything that shares
% the same ID #, Group #, and Trial #).
groupingVariables = {'ID', 'Group', 'New_Trial'};

% Compute the average feedback for each trial
averageFeedback = groupsummary(data, groupingVariables, 'mean', 'Feedback');

% Note: At this point, averageFeedback contains the columns: 
% 'ID', 'Group', 'New_Trial', and 'mean_Feedback'


% Step 2 - merge the reduced feedback table with the data table
% Filter the new data to only include subjects present in the old data
filteredaverageFeedback = averageFeedback(ismember(averageFeedback.ID, Metric_Data.Subject_Number), :);

% Merge the two tables based on common columns ('Subject_Number' and 'Trial_Number')
% Note: 'LeftKeys' specifies the key columns from Metric_Data.
%       'RightKeys' specifies the key columns from filteredaverageFeedback.
%       The 'RightVariables' option specifies which columns from the averageFeedback to include in the merged table.
%       The 'MergeKeys' option ensures that the key columns from both tables are merged into single columns in the output.
mergedData = outerjoin(Metric_Data, filteredaverageFeedback, ...
    'LeftKeys', {'Subject_Number', 'Trial_Number'}, ...
    'RightKeys', {'ID', 'New_Trial'}, ...
    'RightVariables', 'mean_Feedback', ...
    'MergeKeys', true);

% Rename the merged key columns
mergedData = renamevars(mergedData, 'Subject_Number_ID', 'Subject_Number');
mergedData = renamevars(mergedData, 'Trial_Number_New_Trial', 'Trial_Number');

%% Part 4 - get rid of the trials 31-40 and save the table

% Filter out trials 31-40
MT6_Data = mergedData(mergedData.Trial_Number <= 30, :);

% Save the MAT-file for analysis
save('MT6_Data.mat', 'MT6_Data');

% Optionally, save the new table to a .csv file
writetable(MT6_Data, 'MT6_data.csv');
