
function [y_sim, ap, kp, bp, r2, mad, bic] = fit_3parameter_power_model(y,u,ntrials)
% Cost of three-parameter power model
fun = @(x)norm((x(1)*u.^x(2)+x(3))-y)^2;
%This stuff is mostly garbage unless you have a REALLY good reason to mess
%with upper bounds do to unlucky experimental data.
%----
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -1 0]; % lower bound constraint on unknown parameters
ub = [inf 0 inf]; % upper bound constraint on unknown parameters
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
%----

minval = inf;
for i =1:ntrials
   x0 = [i*rand, -rand, i*rand]; %<-- I don't understand why this is used as a basepoint.
   [x1,fval] = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,[],options);
   if(fval<minval)
      xmin = x1;
      minval = fval;
   end
end
ap = xmin(1);
kp = xmin(2);
bp = xmin(3);
y_sim =ap*u.^kp+bp;
r2 = 100*(1-norm(y-y_sim)^2/norm(y-mean(y))^2);
mad = mean(abs(y - y_sim));
%BIC
    rss = sum((y - y_sim).^2);
    n_samples = length(y);
    n_params = 3;
    bic = n_params * log(n_samples) + n_samples * log(rss / n_samples);
end