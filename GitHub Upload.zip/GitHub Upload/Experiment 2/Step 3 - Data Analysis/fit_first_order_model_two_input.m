function [y_sim, retention_rate, learning_rates, offset, xi, r2, mad, bic] = fit_first_order_model_two_input(y, u, ntrials)
Ts = 1;
data = iddata(y, u, Ts);

A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -inf -inf 0 0]; % lower bounds
ub = [1 inf inf inf inf]; % upper bounds
nonlcon = [];
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
minval = inf;

% estimate multiple times with random initialization to achieve global
% minimum (best fitting)
for i = 1:ntrials
    x0 = [rand, i*rand, i*rand, i*rand, i*rand]; % Random initial conditions within bounds
    [x, fval1] = fmincon(@(x) evaluate_cost_fo_u2(x, data), x0, A, b, Aeq, beq, lb, ub, nonlcon, options);
    % keep the best solution so far
    if fval1 < minval
        xmin = x;
        minval = fval1;
    end
end

% Use the optimized solution from the fitting
A = xmin(1);
B = [xmin(2), xmin(3)];
xi = xmin(4);
offset = xmin(5);

retention_rate = A;
learning_rates(1) = B(1);
learning_rates(2) = B(2);
y_sim = zeros(length(y), 1);
y_sim(1) = xi;
for i = 2:length(y)
    y_sim(i) = A * y_sim(i - 1) + B(1) * u(i - 1, 1) + B(2) * u(i - 1, 2) + offset;
end
r2 = 100 * (1 - norm(y - y_sim)^2 / norm(y - mean(y))^2);
mad = mean(abs(y - y_sim));
%BIC
    rss = sum((y - y_sim).^2);
    n_samples = length(y);
    n_params = 5;
    bic = n_params * log(n_samples) + n_samples * log(rss / n_samples);
end

% cost function for model fitting
function cost = evaluate_cost_fo_u2(x, data)
    A = x(1);
    B = [x(2), x(3)];
    y_sim = zeros(length(data.y), 1);
    y_sim(1) = x(4);
    for i = 2:length(data.y)
        y_sim(i) = A * y_sim(i - 1) + B * data.u(i - 1, :)' + x(5);
    end
    cost = (norm(y_sim - data.y))^2;
end
