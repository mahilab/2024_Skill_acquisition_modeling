function [y_sim, retention_rate, learning_rate, offset, xi, r2, mad, bic]...
     = fit_first_order_model(y, u, ntrials)
    
Ts = 1;
data = iddata(y, u, Ts);
A = [];
b = [];
Aeq = [];
beq = [];
lb = [0 -inf 0 0]; % lower bound constraint on unknown parameters
ub = [1 inf inf inf]; % upper bound constraint on unknown parameters
options = optimoptions('fmincon','Display','off','Algorithm','sqp');
minval = inf;

% estimate multiple times with random initialization to achieve global
% minimum (best fitting)
for i = 1:ntrials
    % Changed the initialization to not depend on the exponential model
    x0 = [rand, i*rand, i*rand, i*rand];
    [x1, fval1] = fmincon(@(x) evaluate_cost_fo_u1(x, data), x0, A, b, Aeq, beq, lb, ub, [], options);
    % keep the best solution so far
    if(fval1 < minval)
        xmin = x1;
        minval = fval1;
    end
end

% Use the optimized solution from the fitting
A = xmin(1);
B = xmin(2);
xi = xmin(3);
x_of = xmin(4);
fval = minval;

retention_rate = A;
learning_rate = B;
offset = x_of;
y_sim = zeros(length(y), 1);
y_sim(1) = xi;
for i = 2:length(y)
    y_sim(i) = A * y_sim(i - 1) + B * u(i - 1) + x_of;
end
r2 = 100 * (1 - norm(y - y_sim)^2 / norm(y - mean(y))^2);
mad = mean(abs(y - y_sim));
%BIC
    rss = sum((y - y_sim).^2);
    n_samples = length(y);
    n_params = 4;
    bic = n_params * log(n_samples) + n_samples * log(rss / n_samples);
end

% cost function for model fitting
function cost = evaluate_cost_fo_u1(x, data)
    A = x(1);
    B = x(2);
    y_sim = zeros(length(data.y), 1);
    y_sim(1) = x(3);
    for i = 2:length(data.y)
        y_sim(i) = A * y_sim(i - 1) + B * data.u(i - 1) + x(4);
    end
    cost = (norm(y_sim - data.y))^2;
end
