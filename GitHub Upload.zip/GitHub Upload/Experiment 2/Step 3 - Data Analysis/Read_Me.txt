Step 3 - Data Analysis
______________________

By Charles Weeks
Based on previous work by Priyanshu Agarwall, Jenny Sullivan, and Patrick Yee

The main script for analysis is Fit_All_Models.m. This script is a modified version of Jenny's Fit_Individual_Models.m script (archived on Box). Changes made include: a new model (APEX), changing the fitting algorithms to be consistent accross models and actually match the descriptions in the paper, adding extensive comments/documentation, making the script more flexible for use in future experiments, fixing errors in fit metrics and parameter bounds, adding fits to aggregate data (all and group), adding BIC for model comparison, and shortening the script overall.

REQUIREMENTS:
    data in a .mat table
    Fit_All_Models.m
    fit_3parameter_power_model.m
    fit_4parameter_power_model.m
    fit_exponential_model.m
    fit_APEX_model.m
    fit_first_order_model.m
    fit_first_order_model_two_input.m

This script assumes data is formatted correctly and outliers have already been removed. See folders labeled "Step 1 - Data Formatting" and "Step 2 - Throwing Out Non-Learners" for more information. An example of properly formatted data is MT6_Data.mat in this folder.

TO RUN:
To run this procedure, open Fit_All_Models.m. At the top of this file, there is a "user inputs" section. Fill out these configurable parameters with the names specific to your experimental setup.

This script fits performance (and feedback) data for each subject to the three-parameter power model, the four-parameter power model, the APEX model, the exponential model, FOSI model, and FODI model. It also runs each model on the aggregate data for all subjects and then each group. It assumes that better performance is indicated by decreasing values on the performance metric (e.g., subject gets better by getting fast, their total time taken to complete the task goes down over the course of the experiment). If this is not the case, then the bounds of the parameters in each model's file must be reversed. This script automatically calculates R2, MAD, and BIC. It stores all results in tables P3_Results, P4_Results, EM_Results, AM_Results, FOSI_Results, FODI_Results and saves them to a mat file with the name you specify in the configurable parameters.


This code automatically handles differently numbers of trials or skipped trial numbers, so if your data should not contain either of these things, you should create code to check for them becuase this model fitting code will not throw an error.