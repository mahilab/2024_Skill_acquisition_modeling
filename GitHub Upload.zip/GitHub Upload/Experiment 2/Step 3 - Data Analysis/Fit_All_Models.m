%% Fit_All_Models.m
% by Charles Weeks (crw12@rice.edu)

%% === USER INPUTS ===

% Specify the file name to load data
DataFileName = 'MT6_Data.mat';

% Specify the table's variable name inside the mat file
DataVarName = 'MT6_Data';

% Specify the column label for subject number
SubjectNumberLabel = 'Subject_Number';

% Specify the column label for trial number
TrialNumberLabel = 'Trial_Number';

% Specify the metric/column name used for model fitting
FittingMetricLabel = 'Trial_Time';

% Specify the metric/column name that quantifies the feedback given to
% each subject
FeedbackMetricLabel = 'mean_Feedback';

% Specify the file name to save the final results
ResultsLabel = 'Results';

% Specify if there are groups in the dataset
HasGroups = true;  % true = there are groups; false = there are not groups

% Specify the number of groups (only matters if HasGroups is true)
NumGroups = 3;

% Specify the column label for feedback group
GroupLabel = 'Feedback_Group';

% ================================

%% Initialization

% Create the results tables

P3_Results = table();
P4_Results = table();
EM_Results = table();
AM_Results = table();
FOSI_Results = table();
FODI_Results = table();

% Load trial data
load(DataFileName);
DataVarName = eval(DataVarName);

% Get unique subject numbers
unique_subject_nums = unique(DataVarName.(SubjectNumberLabel));

nattempts = 10; % number of times to run estimation algorithm with random initialization
rng('shuffle'); % randomize random number generator



%% Model Fitting

% Iterate over each unique subject number
for i = 1:length(unique_subject_nums)
    subject_num = unique_subject_nums(i);
    disp(' ');
    
    % Extract the data
    SubjectData = DataVarName(DataVarName.(SubjectNumberLabel) == subject_num, :);
    FittingMetric = SubjectData.(FittingMetricLabel);
    FeedbackMetric = SubjectData.(FeedbackMetricLabel);
    Trial_Count = SubjectData.(TrialNumberLabel);

    % Initialize Trial_number with the current Trial_Count
    Trial_number = Trial_Count;

    % Check if trials need to be renumbered
    if length(unique(Trial_Count)) ~= height(SubjectData) || any(diff(Trial_Count) <= 0)
        warning('Trials are missing or not in ascending order for subject %d. Renumbering trials.', subject_num);
        % If renumbering is required, create a new sequence of trial numbers
        Trial_number = (1:height(SubjectData))';
    end

    N = length(Trial_number);  % This is the number of trials for the current subject
    
    % Determine group for the current subject
    if HasGroups
        Group = unique(SubjectData.(GroupLabel));
        if length(Group) > 1
            error('Subject %d belongs to more than one group. Please check your data.', subject_num);
        end
    else
        Group = 1; % Assign all subjects to the same group if there are no groups
    end
    
    
        disp(' ')
        disp(['---- Begin Subject ' num2str(subject_num) '----'])
        
        %%% Three-Parameter Power Model %%%
        disp(['Fitting three-parameter power model, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_P3, A_P3, K_P3, B_P3, R2_P3, MAD_P3, BIC_P3] = ...
            fit_3parameter_power_model(FittingMetric, Trial_number, nattempts);
        
        NewRow_P3 = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric},{y_sim_P3}, A_P3, K_P3, B_P3, R2_P3, MAD_P3, BIC_P3);
        P3_Results = [P3_Results; NewRow_P3];
        

        %%% Four-Parameter Power Model %%%
        disp(['Fitting four-parameter power model, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_P4, A_P4, K_P4, B_P4, E_P4, R2_P4, MAD_P4, BIC_P4] = ...
            fit_4parameter_power_model(FittingMetric, Trial_number, nattempts);
        
        NewRow_P4 = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric}, {y_sim_P4}, A_P4, K_P4, B_P4, E_P4, R2_P4, MAD_P4, BIC_P4);
        P4_Results = [P4_Results; NewRow_P4];
        
        
        %%% Exponential Model %%%
        disp(['Fitting exponential model, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_EM, A_EM, K_EM, B_EM, R2_EM, MAD_EM, BIC_EM] =...
            fit_exponential_model(FittingMetric, Trial_number, nattempts);
        
        NewRow_EM = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric}, {y_sim_EM}, A_EM, K_EM, B_EM, R2_EM, MAD_EM, BIC_EM);
        EM_Results = [EM_Results; NewRow_EM];
        
        %%% APEX model %%%
        disp(['Fitting APEX model, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_AM, A_AM, K_AA, B_AM, K_AZ, R2_APEX, MAD_APEX, BIC_APEX] =...
            fit_APEX_model(FittingMetric, Trial_number, nattempts);
        
        NewRow_AM = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric}, {y_sim_AM}, A_AM, K_AA, B_AM, K_AZ, R2_APEX, MAD_APEX, BIC_APEX);
        AM_Results = [AM_Results; NewRow_AM];
        
        %%% FOSI model %%%
        disp(['Fitting FOSI model, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_FOSI, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, R2_FOSI, MAD_FOSI, BIC_FOSI] = ...
            fit_first_order_model(FittingMetric, FittingMetric, nattempts);
        
        NewRow_FOSI = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric}, {y_sim_FOSI}, Retention_FOSI, Learning_FOSI, Offset_FOSI, Init_state_FOSI, R2_FOSI, MAD_FOSI, BIC_FOSI);
        FOSI_Results = [FOSI_Results; NewRow_FOSI];
        
        %%% FODI model %%%
        disp(['FITTING FODI MODEL, ' FittingMetricLabel ', Subject ' num2str(subject_num) '..................'])
        [y_sim_FODI,Retention_FODI, Learning_FODI, Offset_FODI, Init_state_FODI, R2_FODI, MAD_FODI, BIC_FODI] =...
            fit_first_order_model_two_input(FittingMetric,[FittingMetric,FeedbackMetric],nattempts);
            
        % Note: 2 learning rate coeffs for FODI
        NewRow_FODI = table(subject_num, Group, {FittingMetricLabel}, {FittingMetric}, {y_sim_FODI}, Retention_FODI, {Learning_FODI}, Offset_FODI, Init_state_FODI, R2_FODI, MAD_FODI, BIC_FODI);
        FODI_Results = [FODI_Results; NewRow_FODI];
        
        disp(['---- End Subject ' num2str(subject_num) '----'])
        
    
end     % for each subject

%% Formatting

P3_Results.Properties.VariableNames = {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'A_P3', 'K_P3', 'B_P3', 'R2', 'MAD', 'BIC'};
P4_Results.Properties.VariableNames = {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'A_P4', 'K_P4', 'B_P4', 'E_P4', 'R2', 'MAD', 'BIC'};
EM_Results.Properties.VariableNames = {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'A_EM', 'K_EM', 'B_EM', 'R2', 'MAD', 'BIC'};
AM_Results.Properties.VariableNames = {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'A_AM', 'K_AA', 'B_AM', 'K_AZ', 'R2', 'MAD', 'BIC'};
FOSI_Results.Properties.VariableNames =  {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'Retention_FOSI', 'Learning_FOSI', 'Offset_FOSI', 'Init_state_FOSI', 'R2', 'MAD', 'BIC'};
FODI_Results.Properties.VariableNames = {SubjectNumberLabel, GroupLabel, 'Metric_Name', 'SubjData', 'FittedData', 'Retention_FODI', 'Learning_FODI', 'Offset_FODI', 'Init_state_FODI', 'R2', 'MAD', 'BIC'};

%% Save Results
save([ResultsLabel '.mat'],'P3_Results','P4_Results','EM_Results', 'AM_Results', 'FOSI_Results','FODI_Results');

disp(['Model fitting is done! Results have been saved to ' ResultsLabel '.mat.'])