% Step 1: Load the .mat file
% Replace 'your_file_name.mat' with the actual name of your .mat file
data = load('AvgResultsX3.mat');

% Step 2: Convert the 'TrialMetric' column to categorical for each table
data.PL_Results.TrialMetric = categorical(data.PL_Results.TrialMetric);
data.GPL_Results.TrialMetric = categorical(data.GPL_Results.TrialMetric);
data.EL_Results.TrialMetric = categorical(data.EL_Results.TrialMetric);
data.AM_Results.TrialMetric = categorical(data.AM_Results.TrialMetric);
data.FOSI_Results.TrialMetric = categorical(data.FOSI_Results.TrialMetric);
data.FODI_Results.TrialMetric = categorical(data.FODI_Results.TrialMetric);

% Step 3: Save the modified tables back to the .mat file
% You can replace 'your_file_name.mat' with a new file name if you prefer
save('AvgResultsX32.mat', '-struct', 'data');
