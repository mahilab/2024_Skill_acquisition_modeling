%% PlotFittedModels.m
% Jenny Sullivan
% Modified by Charles Weeks for MT5 Data
% =============================================

% Uses fitted models stored in ModelResults_Indiv.mat to plot subject data
% and model predictions for GPL, EL, FOSI, and FODI models for the
% user-specified performance metric (AdjTime or SPARC). These plots are based
% on the plots that were in Priyanshu's original scripts
% (model_estimation_without_feedback_individual.m and
% model_estimation_with_feedback_individual.m), but I restructured the
% code so that you can generate the plots without having to re-fit all the
% models (which takes a while). 

% REQUIREMENTS:
%   - ModelResults_Indiv.mat containing the tables: PL_Results,
%   GPL_Results, EL_Results, FOSI_Results, and FODI_Results (created by
%   Fit_Individual_Models.m)

% ================================================

%% USER INPUTS %%

% Choose metric to plot: 'TrialTime' or 'SPARC'
metric = 'TrialTime';

% Plot data as-is or relative to EL:
comp2EL = 0;        % 0/1: if 1, subtracts EL fitted data from all other data series for comparison
plot_order = 1;     % 1/2: order plots by subj num (1) or difference in R2 bet FOSI and EL (2)

%%%%%%%%%%%%%%%%%%%

%% SETUP %%

% If plots ordered by difference in R2 between FOSI and EL, try to find
% DifferenceOrder table:
if plot_order == 2
    % If it exists, sort rows
    if exist('DifferenceOrder','var')
        DifferenceOrder = sortrows(DifferenceOrder,'Order','ascend');
    else
        try
            % If it doesn't exist, try to load and sort it
            load('DifferenceOrder.mat');
            DifferenceOrder = sortrows(DifferenceOrder,'Order','ascend');
        catch
            % If not found, change plot order to default
            disp('Can''t find DifferenceOrder table. Setting plot_order = 1');
            plot_order = 1;
        end
    end
end

% Set specific y ranges for plots
if comp2EL == 1
    if strcmp(metric, 'TrialTime')
        yrange = [-15 20];
    elseif strcmp(metric,'SPARC')
        yrange = [];
    end
else
    if strcmp(metric, 'TrialTime')
        yrange = [20 60];
    elseif strcmp(metric,'SPARC')
        yrange = [4 9];
    end
end

% Order of plots:
switch plot_order
    case 1      % By subj num
        subjnums_grp0 = [5004,5005,5008,5009,5016,5018,5022,5024,5028,5030,5033,5034,5038,5039,5043,5048,5050,5053,5057,5059,5064,5066,5067,5069,5073,5078,5079,5081,5087,5088,5093];
        subjnums_grp1 = [5001,5003,5007,5011,5014,5017,5021,5023,5025,5027,5032,5035,5040,5042,5045,5047,5049,5054,5055,5056,5061,5065,5070,5074,5076,5080,5082,5086,5089,5094,5095];
        subjnums_grp2 = [5002,5006,5010,5012,5013,5015,5019,5020,5026,5029,5031,5036,5037,5041,5044,5046,5051,5052,5058,5060,5062,5063,5068,5072,5075,5077,5083,5084,5085,5090,5091,5092];
        
    case 2      % By difference in R2, FOSI - EL
        subjnums_grp0 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 0 & DifferenceOrder.TrialMetric == metric)';
        subjnums_grp1 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 1 & DifferenceOrder.TrialMetric == metric)';
        subjnums_grp2 = DifferenceOrder.SubjNum(DifferenceOrder.FBGrp == 2 & DifferenceOrder.TrialMetric == metric)';
end

% Load data
load('AVGResultsX32.mat');

line_width = 1;

%% PLOTTING %%

for grp = 0:1;      % for each group
    % If control group:
    if grp == 0     
        subjnums = subjnums_grp0;
        fig_noFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_noFB.Name = ['No FB - ' metric];
    % If smoothness feedback group:
    elseif grp == 1            
        subjnums = subjnums_grp1;
        fig_smthFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_smthFB.Name = ['Smoothness FB - ' metric];
    end
    
    % For each subj:
    for i = [1];       
        subj_num = subjnums(i)
        
        % Get subject's actual data 
        SubjData = GPL_Results.SubjData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        
        % PL: Get predicted values and R2
        FittedData_PL = GPL_Results.FittedData{PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric};
        R2_PL = PL_Results.R2(PL_Results.SubjNum == subj_num & PL_Results.TrialMetric == metric);
        % GPL: Get predicted values and R2
        FittedData_GPL = GPL_Results.FittedData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        R2_GPL = GPL_Results.R2(GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric);
        % EL: Get predicted values and R2
        FittedData_EL = EL_Results.FittedData{EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric};
        R2_EL = EL_Results.R2(EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric);
        % AM: Get predicted values and R2
        FittedData_AM = AM_Results.FittedData{AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric};
        R2_AM = AM_Results.R2(AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric);
        % FOSI: Get predicted values and R2
        FittedData_FOSI = FOSI_Results.FittedData{FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric};
        R2_FOSI = FOSI_Results.R2(FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric);
        
        N = length(SubjData);   % number of trials
        
        % z will be subtracted from all fitted data:
        % - If comp2EL = 0, z = 0
        % - If comp2EL = 1, z = fitted data from EL
        z = comp2EL*FittedData_EL;
        
        % Plot subj data, GPL, EL, and FOSI first
        subplot(1,1,i); hold on;
        plot(1:N,SubjData-z,'-k.','LineWidth',line_width,'MarkerSize',11);
        plot(1:N,FittedData_PL-z,'-','LineWidth',line_width,'color',[0.9290 0.6940 0.1250]);
        plot(1:N,FittedData_GPL-z,'-r','LineWidth',line_width);
        plot(1:N,FittedData_EL-z,'-m','LineWidth',line_width);
        plot(1:N,FittedData_AM-z,'-c','LineWidth',line_width);
        plot(1:N,FittedData_FOSI-z,'-b','LineWidth',line_width);
        
        legend_entries = {'Data',...
            ['3PM'],...
            ['4PM'],...
            ['EM'],...
            ['APEX'],...
            ['FOSI']};
        
        % If subject is in smoothness/position FB group, also plot FODI
        if grp == 1
            % FODI: Get predicted values and R2
            FittedData_FODI = FODI_Results.FittedData{FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric};
            R2_FODI = FODI_Results.R2(FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric);
            
            plot(1:N,FittedData_FODI-z,'-g','LineWidth',line_width);
            legend_entries{end + 1} = ['FODI'];
        end
        
        % Legend formatting
        [h_legend,icons] = legend(legend_entries);
        set(h_legend,'Location','best','Color','none');

        if grp == 0
            lgnd_lines = [1 5 7 9 11];
        else
            lgnd_lines = [1 6 8 10 12 14 15];
        end
        for l = lgnd_lines
            icons(l).Visible = 'off';
        end

        
        % Plot formatting
        ax = gca;
        ax.FontSize = 12;
        grid off;
        xlabel('Trial Number','FontSize',12);
        ylabel('Trial Time (seconds)','FontSize',12);
        axis tight;
        if ~isempty(yrange)
            ylim(yrange);
        end
        %ylimit = ylim;
        %ylim(ylimit+diff(ylimit).*[-0.1 0.8]);
        %title(['subj num ' num2str(subj_num)]);
        
    end     % for each subj
    
    %I commented this all out below becuase it would overlap plot 32 for
    %group 2:
    % Add an additional subplot to serve as a legend
    % ax = subplot(4,8,32); hold on;
    % q = [1;1];
    % plot(q,q,'-k',...
    %    q,q,'-r',...
    %    q,q,'-m',...
    %    q,q,'-c',...
    %    q,q,'-b','LineWidth',line_width);
    
    %legend_entries = {'Data','GPL','EL','AM','FOSI'};
    
    %if grp == 1
    %    plot(1,1,'-g','LineWidth',line_width);
    %    legend_entries{end+1} = 'FODI';
    %end
    
    %h_legend = legend(legend_entries,'Location','northeast');
    %ax.Visible  = 'off';
    
    
end

for grp = 2;      
    % If control group:
    if grp == 2            
        subjnums = subjnums_grp2;
        fig_posFB = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
        fig_posFB.Name = ['Position FB - ' metric];
    end
    
    % For each subj:
    for i = [1];       
        subj_num = subjnums(i)
        
        % Get subject's actual data 
        SubjData = GPL_Results.SubjData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        
        % GPL: Get predicted values and R2
        FittedData_GPL = GPL_Results.FittedData{GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric};
        R2_GPL = GPL_Results.R2(GPL_Results.SubjNum == subj_num & GPL_Results.TrialMetric == metric);
        % EL: Get predicted values and R2
        FittedData_EL = EL_Results.FittedData{EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric};
        R2_EL = EL_Results.R2(EL_Results.SubjNum == subj_num & EL_Results.TrialMetric == metric);
        % AM: Get predicted values and R2
        FittedData_AM = AM_Results.FittedData{AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric};
        R2_AM = AM_Results.R2(AM_Results.SubjNum == subj_num & AM_Results.TrialMetric == metric);
        % FOSI: Get predicted values and R2
        FittedData_FOSI = FOSI_Results.FittedData{FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric};
        R2_FOSI = FOSI_Results.R2(FOSI_Results.SubjNum == subj_num & FOSI_Results.TrialMetric == metric);
        
        N = length(SubjData);   % number of trials
        
        % z will be subtracted from all fitted data:
        % - If comp2EL = 0, z = 0
        % - If comp2EL = 1, z = fitted data from EL
        z = comp2EL*FittedData_EL;
        
        % Plot subj data, GPL, EL, and FOSI first
        subplot(1,1,i); hold on;
        plot(1:N,SubjData-z,'-o',...
            1:N,FittedData_GPL-z,'-r',...
            1:N,FittedData_EL-z,'-m',...
            1:N,FittedData_AM-z,'-c',...
            1:N,FittedData_FOSI-z,'-b','LineWidth',line_width);
        
        legend_entries = {'Data',...
            ['GPL (' sprintf('%0.2f',R2_GPL) '%)'],...
            ['EL (' sprintf('%0.2f',R2_EL) '%)'],...
            ['AM (' sprintf('%0.2f',R2_AM) '%)'],...
            ['FOSI (' sprintf('%0.2f',R2_FOSI) '%)']};
        
        % If subject is in smoothness/position FB group, also plot FODI
        if grp == 2
            % FODI: Get predicted values and R2
            FittedData_FODI = FODI_Results.FittedData{FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric};
            R2_FODI = FODI_Results.R2(FODI_Results.SubjNum == subj_num & FODI_Results.TrialMetric == metric);
            
            plot(1:N,FittedData_FODI-z,'-g','LineWidth',line_width);
            legend_entries{end + 1} = ['FODI (.' sprintf('%0.0f',R2_FODI) ')'];
        end
        
        % Legend formatting
        [h_legend,icons] = legend(legend_entries);
        set(h_legend,'Location','best','Box','off','Color','none');
        if grp == 0
            lgnd_lines = [1 5 7 9 11];
        else
            lgnd_lines = [1 6 8 10 12 14 15];
        end
        for l = lgnd_lines
            icons(l).Visible = 'off';
        end
        
        % Plot formatting
        ax = gca;
        ax.FontSize = 8;
        grid on;
        xlabel('Trial Number','FontSize',7);
        ylabel(metric,'FontSize',7);
        axis tight;
        if ~isempty(yrange)
            ylim(yrange);
        end
        %ylimit = ylim;
        %ylim(ylimit+diff(ylimit).*[-0.1 0.8]);
        title(['subj num ' num2str(subj_num)]);
        
    end     % for each subj
    
    %I commented this all out below becuase it would overlap plot 32 for
    %group 2:
    % Add an additional subplot to serve as a legend
    % ax = subplot(4,8,32); hold on;
    % q = [1;1];
    % plot(q,q,'-k',...
    %    q,q,'-r',...
    %    q,q,'-m',...
    %    q,q,'-b','LineWidth',line_width);
    
    %legend_entries = {'Data','GPL','EL','FOSI'};
    
    %if grp == 1
    %    plot(1,1,'-g','LineWidth',line_width);
    %    legend_entries{end+1} = 'FODI';
    %end
    
   % h_legend = legend(legend_entries,'Location','northeast');
   % ax.Visible  = 'off';
    
    
end