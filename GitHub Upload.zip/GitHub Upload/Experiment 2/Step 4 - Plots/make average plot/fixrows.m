% Load the .mat file
load('AvgResults.mat'); % Replace 'your_file_name.mat' with the name of your file

% List of table names to process
tableNames = {'P3_Results', 'P4_Results', 'EM_Results', 'AM_Results', 'FOSI_Results', 'FODI_Results'};

% Process each table individually
for i = 1:length(tableNames)
    % Dynamically access the table variable
    tableName = tableNames{i};
    eval(['currentTable = ' tableName ';']);
    
    % Extract the first row from the current table
    firstRow = currentTable(1, :);
    
    % Duplicate the first row three times
    replicatedRows = repmat(firstRow, 3, 1);
    
    % Combine the original table with the replicated rows at the top
    updatedTable = [replicatedRows; currentTable];
    
    % Assign the updated table back to the original variable
    eval([tableName ' = updatedTable;']);
end

% Save the modified tables back into a new .mat file
save('AvgResultsX3.mat', 'P3_Results', 'P4_Results', 'EM_Results', 'AM_Results', 'FOSI_Results', 'FODI_Results');

save('AvgResultsX3.mat', 'PL_Results', 'GPL_Results', 'EL_Results', 'AM_Results', 'FOSI_Results', 'FODI_Results');