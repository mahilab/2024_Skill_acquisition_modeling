%% PlotResults.m
% by Charles Weeks (crw12@rice.edu)

% ================================================

%% USER INPUTS %%

% Choose metric to plot
metric = 'Trial_Time';

% Configurable model names (add or remove as needed)
modelNames = {'P3', 'P4', 'EM', 'AM', 'FOSI', 'FODI'};

% Define colors for each model plot (ensure this list matches the modelNames list)
modelColors = {
    [0.8500, 0.3250, 0.0980], % A red-orange for P3
    [0.9290, 0.6940, 0.1250], % A yellow for P4
    [0, 0.4470, 0.7410],      % A blue for EM
    [0.4940, 0.1840, 0.5560], % A purple for APEX
    [0.4660, 0.6740, 0.1880], % A green for FOSI
    [0.3010, 0.7450, 0.9330]  % A light blue for FODI
};

% ================================================

%% SETUP %%

% Load data
load('Results.mat');

% Determine group numbers and subject numbers
groups = unique([P3_Results.Feedback_Group]);
groupSubjectNumbers = arrayfun(@(g) unique(P3_Results.Subject_Number(P3_Results.Feedback_Group == g)), groups, 'UniformOutput', false);

line_width = 1;

%% PLOTTING %%

for g = 1:length(groups)
    groupNum = groups(g);
    subjnums = groupSubjectNumbers{g};
    
    % Define the number of rows and columns for subplots
    nSubj = length(subjnums);
    nCols = ceil(sqrt(nSubj)); % This would balance between rows and columns
    nRows = ceil(nSubj / nCols);

    % Increase figure size
    fig = figure('DefaultLegendFontSize',7,'DefaultLegendFontSizeMode','manual');
    fig.Position = [100, 100, 1200, 300*nRows]; % You can adjust the size [left, bottom, width, height]
    fig.Name = ['Group ' num2str(groupNum)];

    % Plot each subject's data
    for i = 1:nSubj
        subj_num = subjnums(i);

        % Adjust subplot grid as needed
        sp = subplot(nRows, nCols, i); 
        hold on; 

        % Initialize the arrays for plot handles and legend entries
        plot_handles = [];
        legend_entries = {};

        % Plot each model's data
        for m = 1:length(modelNames)
            modelName = modelNames{m};
            modelResultVar = eval([modelName '_Results']); % Dynamic variable name access

            % Get subject's actual data if it's the first model
            if m == 1 && ~isempty(modelResultVar.SubjData)
                SubjData = modelResultVar.SubjData{modelResultVar.Subject_Number == subj_num};
                data_plot = plot(1:length(SubjData), SubjData, '-k.', 'LineWidth', line_width, 'MarkerSize', 11);
                plot_handles(end + 1) = data_plot; % Add to handles
                legend_entries{end + 1} = 'Data';
            end

            % Get predicted values and R2
            FittedData = modelResultVar.FittedData{modelResultVar.Subject_Number == subj_num};
            R2 = modelResultVar.R2(modelResultVar.Subject_Number == subj_num);

            % Plot model data
            model_plot = plot(1:length(FittedData), FittedData, '-', 'LineWidth', line_width, 'Color', modelColors{m});
            plot_handles(end + 1) = model_plot; % Add to handles
            legend_entries{end + 1} = [modelName ' (.' sprintf('%0.0f', R2) ')'];
        end

        % Legend formatting
        legend(plot_handles, legend_entries, 'Location', 'best', 'Box', 'off'); % Use plot handles for legend entries

        % Plot formatting
        ax = gca;
        ax.FontSize = 8;
        grid off;
        xlabel('Trial Number', 'FontSize', 8);
        ylabel('Trial Time (Seconds)', 'FontSize', 8); % Adjust ylabel to reflect the metric's units
        axis tight;
        
        title(['Subject ' num2str(subj_num)], 'FontSize', 8);
    end
end

% Add any code here to save the figures if necessary
