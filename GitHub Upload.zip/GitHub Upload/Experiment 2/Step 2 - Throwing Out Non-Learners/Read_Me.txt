Part 2 - Throwing Out Non-Learners
________________________

By Charles Weeks (crw12@rice.edu)
Based on code created by Patrick Yee

For an description of the outlier detection process being employed here, please read ________.pdf.

REQUIREMENTS:
    data in a .mat table
    findRandomOutliers.m
    checkOutlier.m

This file requires a .mat table file properly formatted as explained in the previous step. It should have at least four columns (exact names do not matter): subject number, trial number, performance metric, and average feedback given on that trial. You can add additional columns for additional performance metrics you plan on analyzing or for group assignments. Each subject will have as many rows as they have trials.

TO RUN:
To run this procedure, open findRandomOutliers.m. At the top of this file, there is a "user inputs" section. Fill out these configurable parameters with the names specific to your experimental setup. This file will archive your original data with "Old_" prefixed to the file name. It will replace your original data file with a new version of with all the outliers removed. It will also produce an output called outliers_summary.txt which summarizes which outliers were removed.

To modify any of the technical parts of the outlier detection process, you will need to open checkOutlier.m, but this should not be necessary if you simply wish to replicate what I have done here.

Don't forget to set your working directory to the location of all these files.