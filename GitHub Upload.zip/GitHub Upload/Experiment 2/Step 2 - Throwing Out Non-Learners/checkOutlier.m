function [lowerBound, subjSlope] = checkOutlier(subjData)
    %CHECKOUTLIER This uses a random machine to check if a subject is an outlier.
    P = 95; %percentile
    numTrials = 100000; %Number of times to run the random machine
    [coef, ~] = polyfit((1:30)', subjData, 1);
    subjSlope = coef(1);

    simulSlopes = zeros(1,numTrials);
    for j = 1:numTrials
        testSlope = 1;
        while testSlope > 0
            testSlope = makeSim(subjData);
        end

        simulSlopes(j) = testSlope;
    end
    lowerBound = prctile(simulSlopes, P);
end

function simulSlope = makeSim(subjData)
    % Make a random trial from subject data
    N = length(subjData);
    diffs = zeros(1,N-1);
    pm1=[-1,1];

    for j=1:N-1
        diffs(j) = abs(subjData(j+1)-subjData(j));
    end

    simul = subjData;

    for j=2:N
        simul(j) = simul(j-1) + pm1(randi(2)) * diffs(randi(length(diffs)));
    end

    [coef, ~] = polyfit((1:30)', simul', 1);
    simulSlope = coef(1);
end
