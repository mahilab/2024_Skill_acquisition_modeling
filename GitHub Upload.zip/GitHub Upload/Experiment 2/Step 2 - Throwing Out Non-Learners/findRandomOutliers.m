%% findRandomOutliers.m
% By Charles Weeks (crw12@rice.edu)

function results = findRandomOutliers()

    % === USER INPUTS ===

    % Specify the file name to load data
    FileName = 'MT6_Data.mat';
    
    % Specify the table's name
    DataVarName = 'MT6_Data';

    % Specify the metric/column name used for outlier detection
    Metric = 'Trial_Time';

    % Specify if there are groups in the dataset
    HasGroups = true;  % Change to true if there are groups, false if not

    % Specify the number of groups (only matters if HasGroups is true)
    NumGroups = 3; 

    % Specify the labels for subject number and feedback group columns
    SubjectNumberLabel = 'Subject_Number';
    FeedbackGroupLabel = 'Feedback_Group';
    
    %ADD LABEL FOR GROUP NAME
    
    % ================================

    % Load the data
    load(FileName);
    
    % Archive the old data
    oldFileName = ['Old_' FileName];
    save(oldFileName, DataVarName);

    % Initialize results matrix
    numSubjects = max(eval([DataVarName '.' SubjectNumberLabel]));
    results = zeros(numSubjects, 4);

    % Loop over each subject
    outlierSubjectsToRemove = []; % Keep track of subjects to remove
    for subjNum = 1:numSubjects
        subjectData = eval([DataVarName '(' DataVarName '.' SubjectNumberLabel ' == ' num2str(subjNum) ', :)']);
        
        % Check if subjectData is empty and skip if so
        if isempty(subjectData)
            continue;
        end
        
        % Store subject number
        results(subjNum,1) = subjNum;
        
        % Store feedback group (only if groups exist)
        if HasGroups
            results(subjNum,3) = eval(['subjectData.' FeedbackGroupLabel '(1)']);
        end
        
        % Get the data for the chosen metric and check for outliers
        subjMetricData = eval(['subjectData.' Metric]);
        [lowerBound, subjSlope] = checkOutlier(subjMetricData);
        
        % If the subject's slope is greater than the lowerBound, flag as outlier
        if subjSlope > lowerBound
            results(subjNum,2) = 1;
            outlierSubjectsToRemove = [outlierSubjectsToRemove; subjNum];
        end
    end
    
    % Remove outlier subjects from the data
    for outlierSubj = outlierSubjectsToRemove'
        eval([DataVarName '(' DataVarName '.' SubjectNumberLabel ' == ' num2str(outlierSubj) ', :) = [];']);
    end
    eval(['save(FileName, ''' DataVarName ''');']); % Save the modified data
    
    % Prepare the summary for saving
    summaryText = ['Total outliers: ' num2str(sum(results(:, 2))) '\n'];

    if HasGroups
        for group = 1:NumGroups
            groupOutliers = sum(results(:, 2) & results(:, 3) == group);
            summaryText = [summaryText 'Group ' num2str(group) ' outliers: ' num2str(groupOutliers) '\n'];
            
            outlierSubjects = results((results(:, 2) == 1) & (results(:, 3) == group), 1)';
            summaryText = [summaryText 'Subject Numbers for Group ' num2str(group) ' outliers: ' num2str(outlierSubjects) '\n\n'];
        end
    else
        outlierSubjects = results(results(:, 2) == 1, 1)';
        summaryText = [summaryText 'Subject Numbers for outliers: ' num2str(outlierSubjects) '\n\n'];
    end

    % Save the summary to a text file
    fileId = fopen('outliers_summary.txt', 'w');
    fprintf(fileId, summaryText);
    fclose(fileId);

    disp('Outliers summary saved to "outliers_summary.txt".');

end
